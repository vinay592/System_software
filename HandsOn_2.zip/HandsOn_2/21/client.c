/*
================================================================================
Name : 21a
Author : Vinay V Bhandare
Description : Two-way communication using FIFO (Client side)
Date : 26th Sept 2025
================================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

#define FIFO1 "fifo1"
#define FIFO2 "fifo2"

int main()
{
    int fd1, fd2;
    char buf[128];

    mkfifo(FIFO1, 0666);
    mkfifo(FIFO2, 0666);

    fd1 = open(FIFO1, O_WRONLY);
    fd2 = open(FIFO2, O_RDONLY);

    while (1)
    {
        printf("Client: ");
        fgets(buf, sizeof(buf), stdin);
        write(fd1, buf, strlen(buf) + 1);

        if (strncmp(buf, "exit", 4) == 0)
            break;

        read(fd2, buf, sizeof(buf));
        printf("Server says: %s", buf);
    }

    close(fd1);
    close(fd2);
    return 0;
}
/*
Output:
vinay-v-bhandare@vinay-v-bhandare-Inspiron-5490:~/SS/HandsOn_2/21$ ./client
Client: hello
Server says: hi maga
Client: what u doing
Server says: just chillin
Client: lets go to kantara chapter - 1???
Server says: yess lezzgoooo bye
Client: byeeee
Server says: exit
Client: exit

*/ 
