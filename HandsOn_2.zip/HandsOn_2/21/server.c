/*
================================================================================
Name : 21b
Author : Vinay V Bhandare
Description : Two-way communication using FIFO (Server side)
Date : 26th Sept 2025
================================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

#define FIFO1 "fifo1"
#define FIFO2 "fifo2"

int main()
{
    int fd1, fd2;
    char buf[128];

    mkfifo(FIFO1, 0666);
    mkfifo(FIFO2, 0666);

    fd1 = open(FIFO1, O_RDONLY);
    fd2 = open(FIFO2, O_WRONLY);

    while (1)
    {
        read(fd1, buf, sizeof(buf));
        if (strncmp(buf, "exit", 4) == 0)
            break;

        printf("Client says: %s", buf);

        printf("Server: ");
        fgets(buf, sizeof(buf), stdin);
        write(fd2, buf, strlen(buf) + 1);
    }

    close(fd1);
    close(fd2);
    return 0;
}
/*
Output:
vinay-v-bhandare@vinay-v-bhandare-Inspiron-5490:~/SS/HandsOn_2/21$ ./server
Client says: hello
Server: hi maga
Client says: what u doing
Server: just chillin
Client says: lets go to kantara chapter - 1???
Server: yess lezzgoooo bye
Client says: byeeee
Server: exit
*/
