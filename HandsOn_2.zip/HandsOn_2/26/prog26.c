/*
================================================================================
Name : 26
Author : Vinay V Bhandare
Description : Sends messages to a System V message queue and can be verified with ipcs -q
Date : 26th Sept 2025
================================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

struct msg_buffer
{
    long msg_type;
    char msg_text[128];
};

int main()
{
    key_t key;
    int msgid;
    struct msg_buffer message;

    key = ftok(".", 'M');
    if (key == -1)
    {
        perror("Failed to generate key");
        exit(1);
    }

    msgid = msgget(key, 0666 | IPC_CREAT);
    if (msgid == -1)
    {
        perror("Failed to access message queue");
        exit(1);
    }

    message.msg_type = 1;
    printf("Enter message to send: ");
    fgets(message.msg_text, sizeof(message.msg_text), stdin);

    if (msgsnd(msgid, &message, sizeof(message.msg_text), 0) == -1)
    {
        perror("Failed to send message");
        exit(1);
    }

    printf("Message sent successfully.\n");
    return 0;
}

/* 
Sample Output:
vinay-v-bhandare@vinay-v-bhandare-Inspiron-5490:~/SS/HandsOn_2/26$ ./a.out
Enter message to send: Hii
Message sent successfully.
vinay-v-bhandare@vinay-v-bhandare-Inspiron-5490:~/SS/HandsOn_2/26$ ipcs -q

------ Message Queues --------
key        msqid      owner      perms      used-bytes   messages    
0x4d0a0867 0          vinay-v-bh 666        0            0           
0x4d0a0868 1          vinay-v-bh 666        0            0           
0x4d0a0869 2          vinay-v-bh 666        128          1           


*/

