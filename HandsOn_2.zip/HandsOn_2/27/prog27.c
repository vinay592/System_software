/*
================================================================================
Name : 27
Author : Vinay V Bhandare
Description : Program to receive messages from a message queue
              a. with 0 as a flag (blocking)
              b. with IPC_NOWAIT as a flag (non-blocking)
Date : 29th Sept 2025
================================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>

struct msg_buffer {
    long mtype;
    char mtext[100];
};

int main()
{
    key_t key;
    int msgid;
    struct msg_buffer message;

    key = ftok("msgfile", 65);

    msgid = msgget(key, 0666 | IPC_CREAT);
    if (msgid == -1) {
        perror("msgget failed");
        exit(1);
    }

    printf("Receiving message with flag = 0 (blocking)...\n");
    if (msgrcv(msgid, &message, sizeof(message.mtext), 1, 0) == -1) {
        perror("msgrcv blocking failed");
        exit(1);
    }
    printf("Received (blocking): %s\n", message.mtext);

    printf("Receiving message with flag = IPC_NOWAIT (non-blocking)...\n");
    if (msgrcv(msgid, &message, sizeof(message.mtext), 1, IPC_NOWAIT) == -1) {
        if (errno == ENOMSG) {
            printf("No message available (non-blocking)\n");
        } else {
            perror("msgrcv non-blocking failed");
            exit(1);
        }
    } else {
        printf("Received (non-blocking): %s\n", message.mtext);
    }

    return 0;
}

/*
Output:
Receiving message with flag = 0 (blocking)...
Received (blocking): Hello Message
Receiving message with flag = IPC_NOWAIT (non-blocking)...
No message available (non-blocking)
*/

