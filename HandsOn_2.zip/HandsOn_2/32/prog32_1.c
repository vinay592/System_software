/*
===============================================================================
Name : 32
Author : Vinay V Bhandare
Description : Program to implement semaphore to protect any critical section.
              a. Rewrite the ticket number creation program using semaphore
              b. Protect shared memory from concurrent write access
              c. Protect multiple pseudo resources (two) using counting semaphore
              d. Remove the created semaphore
===============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/types.h>

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};


void sem_wait(int semid, int semnum) {
    struct sembuf sb = {semnum, -1, 0};
    if (semop(semid, &sb, 1) == -1) {
        perror("sem_wait failed");
        exit(1);
    }
}

void sem_signal(int semid, int semnum) {
    struct sembuf sb = {semnum, 1, 0};
    if (semop(semid, &sb, 1) == -1) {
        perror("sem_signal failed");
        exit(1);
    }
}

int main() {
    key_t key = ftok("semfile", 65);
    if (key == -1) {
        perror("ftok failed");
        exit(1);
    }

    // create 2 semaphores for part (c)
    int semid = semget(key, 2, 0666 | IPC_CREAT);
    if (semid == -1) {
        perror("semget failed");
        exit(1);
    }

    union semun u;
    unsigned short values[2] = {1, 2};
    u.array = values;
    if (semctl(semid, 0, SETALL, u) == -1) {
        perror("semctl init failed");
        exit(1);
    }

    printf("Semaphore set created with id: %d\n", semid);

    // (a) Ticket creation using binary semaphore
    int shmid = shmget(1234, sizeof(int), 0666 | IPC_CREAT);
    if (shmid == -1) {
        perror("shmget failed");
        exit(1);
    }

    int *ticket = (int *)shmat(shmid, NULL, 0);
    if (ticket == (void *)-1) {
        perror("shmat failed");
        exit(1);
    }

    if (*ticket == 0) *ticket = 100; 

    for (int i = 0; i < 5; i++) {
        sem_wait(semid, 0);
        printf("Process %d got ticket: %d\n", getpid(), (*ticket)++);
        sem_signal(semid, 0);
        sleep(1);
    }

    // (b) Protect shared memory write
    sem_wait(semid, 0);
    printf("Process %d writing to shared memory...\n", getpid());
    *ticket += 10; // critical section
    sem_signal(semid, 0);

    // (c) Protect multiple resources using counting semaphore
    sem_wait(semid, 1); 
    printf("Process %d acquired a resource\n", getpid());
    sleep(2); 
    printf("Process %d releasing resource\n", getpid());
    sem_signal(semid, 1);

    // (d) Remove semaphore set
    if (semctl(semid, 0, IPC_RMID) == -1) {
        perror("semctl remove failed");
        exit(1);
    }
    printf("Semaphore set removed.\n");

    shmdt(ticket);
    shmctl(shmid, IPC_RMID, NULL);

    return 0;
}
/*
vinay-v-bhandare@vinay-v-bhandare-Inspiron-5490:~/SS/HandsOn_2/32$ ./a.out
Semaphore set created with id: 2
Process 44906 got ticket: 100
Process 44906 got ticket: 101
Process 44906 got ticket: 102
Process 44906 got ticket: 103
Process 44906 got ticket: 104
Process 44906 writing to shared memory...
Process 44906 acquired a resource
Process 44906 releasing resource
Semaphore set removed.
*/
