/*
================================================================================
Name : 8a
Author : Vinay V Bhandare
Description : Catch SIGSEGV signal
Date : 20th Sept 2025
================================================================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void handler(int sig)
{
    printf("Caught SIGSEGV\n");
    exit(1);
}

int main()
{
    signal(SIGSEGV, handler);
    int *ptr = NULL;
    *ptr = 10;
    return 0;
}

/* Output:
Caught SIGSEGV
*/
 
