/*
================================================================================
Name : 8b
Author : Vinay V Bhandare
Description : Catch SIGINT signal
Date : 20th Sept 2025
================================================================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void handler(int sig)
{
    printf("Caught SIGINT\n");
    exit(0);
}

int main()
{
    signal(SIGINT, handler);
    while(1)
    {
    }
    return 0;
}

/* Output:
(Ctrl+C pressed)
Caught SIGINT
*/

