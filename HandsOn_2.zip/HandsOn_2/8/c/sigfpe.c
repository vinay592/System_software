/*
================================================================================
Name : 8c
Author : Vinay V Bhandare
Description : Catch SIGFPE signal
Date : 20th Sept 2025
================================================================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void handler(int sig)
{
    printf("Caught SIGFPE\n");
    exit(1);
}

int main()
{
    signal(SIGFPE, handler);
    int a = 5, b = 0;
    int c = a / b;
    printf("%d\n", c);
    return 0;
}

/* Output:
Caught SIGFPE
*/

